const SlidesMark =  {
    marksAmt : [
       {value:'0' ,label:'15l'},
    {value:'100000',label:'150l'},
    {value:'200000',label:'300l'},
    {value:'300000',label:'450l'},
    {value:'400000',label:'600l'},
    {value:'500000',label:'750l'}
],
marksInt : [
    {value:'0',label:'0'},
    {value:'10',label:'10'},
    {value:'20',label:'20'},
    {value:'30',label:'30'},
    {value:'40',label:'40'},
    {value:'50',label:'50'},
],
  marksTime : [
    {value:'0',label:'0'},
    {value:'1',label:'1'},
    {value:'2',label:'2'},
    {value:'3',label:'3'}
  ]
  
}

export default SlidesMark;
